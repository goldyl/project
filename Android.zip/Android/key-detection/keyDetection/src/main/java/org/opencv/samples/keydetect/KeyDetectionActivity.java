package org.opencv.samples.keydetect;

import java.util.Arrays;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2;
import org.opencv.imgproc.Imgproc;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnTouchListener;
import android.view.SurfaceView;

public class KeyDetectionActivity extends Activity implements OnTouchListener, CvCameraViewListener2 {
    private static final String TAG = "OCVSample::Activity";
    private static final int KEY_START_PATTERN_SIZE = 8;
    private static final int KEY_SIZE = 8;

    private boolean mIsColorSelected = false;
    private Mat mRgba;
    private Scalar mBlobColorRgba;
    private Scalar mBlobColorHsv;
    private KeyDetector mDetector;
    private Mat mSpectrum;
    private Size SPECTRUM_SIZE;
    private Scalar CONTOUR_COLOR;

    private CameraBridgeViewBase mOpenCvCameraView;

    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS: {
                    Log.i(TAG, "OpenCV loaded successfully");
                    mOpenCvCameraView.enableView();
                    mOpenCvCameraView.setOnTouchListener(KeyDetectionActivity.this);
                }
                break;
                default: {
                    super.onManagerConnected(status);
                }
                break;
            }
        }
    };

    public KeyDetectionActivity() {
        Log.i(TAG, "Instantiated new " + this.getClass());
    }

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "called onCreate");
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.key_detection_surface_view);

        mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.key_detection_activity_surface_view);
        mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);
        mOpenCvCameraView.setCvCameraViewListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!OpenCVLoader.initDebug()) {
            Log.d(TAG, "Internal OpenCV library not found. Using OpenCV Manager for initialization");
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_0_0, this, mLoaderCallback);
        } else {
            Log.d(TAG, "OpenCV library found inside package. Using it!");
            mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
        }
    }

    public void onDestroy() {
        super.onDestroy();
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }

    public void onCameraViewStarted(int width, int height) {
        mRgba = new Mat(height, width, CvType.CV_8UC4);
        mDetector = new KeyDetector();
        mSpectrum = new Mat();
        mBlobColorRgba = new Scalar(255);
        mBlobColorHsv = new Scalar(255);
        SPECTRUM_SIZE = new Size(200, 64);
        CONTOUR_COLOR = new Scalar(255, 0, 0, 255);
    }

    public void onCameraViewStopped() {
        mRgba.release();
    }

    public boolean onTouch(View v, MotionEvent event) {
        mIsColorSelected = true;

        return false; // don't need subsequent touch events
    }

    public Mat onCameraFrame(CvCameraViewFrame inputFrame) {
        byte[] startKeyPattern = {1, 0, 1, 0, 0, 1, 0, 1}; //A5 MSB first
        byte[] startKey = new byte[KEY_START_PATTERN_SIZE];
        byte[] key = new byte[KEY_SIZE];
        int keyIndex = 0;
        Arrays.fill(startKey, (byte) 2);
        int matchingIndex = -1; //index of bit for matching pattern found (in pattern array)

        mRgba = inputFrame.rgba();

        if (mIsColorSelected) {

//            mRgba = mDetector.process(mRgba);
            mDetector.process(mRgba);
            mRgba = setText(mRgba, mDetector.isLedOn() ? 1 : 0);

            boolean startKeyDetected = false;


            if (startKeyDetected == false) { //wait for start of key pattern
                //shift left
                System.arraycopy(startKey, 0, startKey, 0, startKey.length - 1);
                //add new char
                startKey[startKey.length - 1] = mDetector.isLedOn() ? (byte) 1 : (byte) 0;
                //compare
                startKeyDetected = Arrays.equals(startKey, startKeyPattern) ? true : false;
            } else { //collect key
                key[keyIndex] = mDetector.isLedOn() ? (byte) 1 : (byte) 0;
                if (keyIndex == KEY_SIZE) {
                    startKeyDetected = false;
                    keyIndex = 0;
                } else
                    keyIndex++;
            }
        }

        return mRgba;

    }


    /*
    function processes image and returns true if a LED on is detected and false if not.
     */
    public Mat setText(Mat image, int value) {
        Imgproc.putText(image, Integer.toString(value),
                new Point(image.width() / 2, image.height() / 2),
                Core.FONT_HERSHEY_PLAIN, 8.0, new Scalar(255, 0, 0), 4);
        return image;
    }

}
